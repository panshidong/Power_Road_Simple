#!/usr/bin/env python3
"""Independent one-hour review of a specific frozen Austin background launch.

No solver imports or numerical changes. A healthy run continues unchanged;
an unhealthy active run receives the supervisor's ordinary stop request.
"""
from __future__ import annotations
import argparse
from datetime import datetime, timedelta
import fcntl
import json
import math
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time
import traceback
from zoneinfo import ZoneInfo


def now():
    return datetime.now(ZoneInfo("America/Chicago")).isoformat(timespec="seconds")


def read(path):
    return json.loads(Path(path).read_text())


def write(path, value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    fd,name=tempfile.mkstemp(dir=path.parent,prefix=path.name+".",suffix=".tmp")
    try:
        with os.fdopen(fd,"w") as handle:
            json.dump(value,handle,ensure_ascii=False,allow_nan=False,indent=2)
            handle.write("\n");handle.flush();os.fsync(handle.fileno())
        os.replace(name,path)
    finally:
        if os.path.exists(name):os.unlink(name)


def process(pid):
    try:
        # comm may itself contain parentheses or whitespace.
        values=Path(f"/proc/{int(pid)}/stat").read_text().rsplit(")",1)[1].split()
        return dict(pid=int(pid),state=values[0],ppid=int(values[1]),start_ticks=int(values[19]))
    except (FileNotFoundError,ProcessLookupError):return None


def matching_process(identity):
    actual=process(identity["pid"])
    return bool(actual and actual["start_ticks"]==identity["start_ticks"] and actual["state"] not in ("Z","X"))


def same_process(left, right):
    return bool(left and right and left["pid"]==right["pid"] and left["start_ticks"]==right["start_ticks"])


def assess(output, request):
    output=Path(output);state=read(output/"control/status.json");spec=read(output/"control/launch.json")
    answer=dict(checked_at=now(),requested_check_at=request["check_at"],run=str(output),
                status=state.get("status"),stage=state.get("stage"),progress=state.get("progress",{}),
                report_name=request["report_name"],supervisor=request["supervisor"],
                continued=False,stop_requested=False,issues=[])
    if (state.get("supervisor_pid")!=request["supervisor"]["pid"] or
        state.get("started_or_resumed_at")!=request["launch_started_at"] or
        spec["fingerprint"]!=request["numerical_fingerprint"]):
        return dict(answer,decision="superseded",issues=["A different launch now owns this output; no action taken"])
    if state.get("status")=="completed":return dict(answer,decision="completed")
    if state.get("status")!="running":
        return dict(answer,decision="already_stopped",issues=[state.get("reason",state.get("status","unknown"))])
    issues=answer["issues"]
    if not matching_process(request["supervisor"]):issues.append("Supervisor process is absent or its PID was reused")
    heartbeat=datetime.fromisoformat(state["heartbeat"]).timestamp()
    answer["heartbeat_age_seconds"]=max(0.,time.time()-heartbeat)
    if answer["heartbeat_age_seconds"]>180:issues.append("Supervisor heartbeat is older than three minutes")
    stage=process(state.get("stage_pid",0))
    answer["stage_process_alive"]=bool(stage and stage["state"] not in ("Z","X") and stage["ppid"]==request["supervisor"]["pid"])
    if not answer["stage_process_alive"]:issues.append("Current stage process is absent or no longer belongs to the supervisor")
    errors=list((output/"results").glob("*/*.error.json"))
    new_errors=[p for p in errors if p.stat().st_mtime>=request["scheduled_epoch"]-2]
    answer["new_error_files"]=[str(p.relative_to(output)) for p in new_errors]
    if new_errors:issues.append("New experiment errors were saved")
    recoveries=[]
    for root in (output/"scratch",output/"validation_scratch"):
        for path in root.rglob("recovery.json"):
            item=read(path)
            recoveries.append(dict(status=item.get("status"),region=item.get("region"),
                                   audit=str(path.relative_to(output))))
    # Disclose contained native faults even when independent confirmation made
    # it safe to continue. A recovery is not evidence that the native bug is gone.
    answer["native_recoveries"]=recoveries
    cache=Path(spec["config"]["runtime"]["cache"])/spec["fingerprint"]
    candidates=list((output/"results").glob("*/*.json"))+list((output/"checkpoints").glob("*/*.json"))
    candidates+=list(cache.glob("traffic/*.npz"))+list(cache.glob("power/*/*.json"))+list(cache.glob("od/*.json"))
    candidates=[p for p in candidates if not p.name.endswith(".error.json")]
    latest=max((p.stat().st_mtime for p in candidates),default=0.)
    answer["seconds_since_saved_progress"]=max(0.,time.time()-latest) if latest else None
    if not latest or time.time()-latest>request["max_idle_seconds"]:
        issues.append("No saved physical state/result/checkpoint progress in the last 15 minutes")
    gate=output/"validation.json"
    validation=read(gate) if gate.exists() else {}
    answer["validation_passed"]=bool(validation.get("passed") and validation.get("fingerprint")==spec["fingerprint"])
    if not answer["validation_passed"]:issues.append("Matching physical acceptance has not passed")
    return dict(answer,decision="unhealthy" if issues else "continue",continued=not issues)


def review(output, request):
    control=Path(output)/"control"
    # Serialize with scheduling and with an explicit resume. A stale watcher
    # must never stop a new launch or overwrite its scheduled review.
    with (control/"health_check.lock").open("a+") as lock, (control/"launch.lock").open("a+") as launch_lock:
        fcntl.flock(lock,fcntl.LOCK_EX);fcntl.flock(launch_lock,fcntl.LOCK_EX)
        try:
            result=assess(output,request)
            # Avoid misclassifying the few seconds of transition between stages.
            if result["decision"]=="unhealthy" and result["issues"]==["Current stage process is absent or no longer belongs to the supervisor"]:
                time.sleep(3);result=assess(output,request)
            if result["decision"]=="unhealthy":
                write(control/"stop.request",dict(requested_at=now(),source="one_hour_review",reason=result["issues"],
                      supervisor=request["supervisor"],launch_started_at=request["launch_started_at"]))
                result["stop_requested"]=True
        except Exception:
            result=dict(decision="check_failed",checked_at=now(),continued=False,stop_requested=False,
                        report_name=request["report_name"],error=traceback.format_exc())
        write(control/request["report_name"],result)
        current=control/"health_check.json"
        if not current.exists() or read(current).get("report_name")==request["report_name"]:
            write(current,result)
        return result


def schedule(output, after):
    output=Path(output).resolve();control=output/"control"
    with (control/"health_check.lock").open("a+") as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        state=read(control/"status.json")
        if state["status"]!="running":raise RuntimeError("Can only schedule a check for a running launch")
        identity=process(state["supervisor_pid"])
        if not identity or not matching_process(identity):raise RuntimeError("Supervisor is not alive")
        current=control/"health_check.json"
        if current.exists():
            existing=read(current)
            if (existing.get("decision")=="scheduled" and same_process(existing.get("supervisor"),identity) and
                existing.get("launch_started_at")==state["started_or_resumed_at"] and
                existing.get("watcher") and matching_process(existing["watcher"])):
                print(json.dumps(existing,ensure_ascii=False,indent=2));return
        epoch=time.time();stamp=time.time_ns()
        request=dict(decision="scheduled",scheduled_at=now(),scheduled_epoch=epoch,
            check_epoch=epoch+after,check_at=(datetime.now(ZoneInfo("America/Chicago"))+timedelta(seconds=after)).isoformat(timespec="seconds"),
            supervisor=identity,launch_started_at=state["started_or_resumed_at"],max_idle_seconds=900,
            report_name=f"health-review-{stamp}.json",numerical_fingerprint=state["fingerprint"])
        request_path=control/f"health-review-{stamp}.request.json";write(request_path,request)
        frozen=control/f"health-review-{stamp}.py";shutil.copy2(__file__,frozen)
        with (control/f"health-review-{stamp}.log").open("a") as log:
            child=subprocess.Popen([sys.executable,str(frozen),"_watch",str(output),"--request",str(request_path)],
                stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True,close_fds=True)
        request["watcher"]=process(child.pid)
        if not request["watcher"]:raise RuntimeError("Review process exited during launch; inspect its log")
        write(current,request)
        print(json.dumps(request,ensure_ascii=False,indent=2),flush=True)
        return child


def watch(output, request_path):
    request=read(request_path)
    while time.time()<request["check_epoch"]:
        try:state=read(Path(output)/"control/status.json")
        except (OSError,ValueError):break
        if state.get("status")!="running" or not matching_process(request["supervisor"]):break
        if state.get("supervisor_pid")!=request["supervisor"]["pid"]:break
        time.sleep(min(30,max(0.,request["check_epoch"]-time.time())))
    result=review(output,request)
    print(json.dumps(result,ensure_ascii=False,indent=2),flush=True)
    return 0 if result["decision"] in ("continue","completed","superseded") else 1


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command",choices=("schedule","_watch"));parser.add_argument("output",type=Path)
    parser.add_argument("--after-seconds",type=float,default=3600);parser.add_argument("--request",type=Path)
    args=parser.parse_args()
    if not math.isfinite(args.after_seconds) or args.after_seconds<=0:parser.error("Delay must be positive and finite")
    if args.command=="schedule":schedule(args.output,args.after_seconds)
    elif not args.request:parser.error("_watch requires --request")
    else:return watch(args.output,args.request)


if __name__=="__main__":raise SystemExit(main())
