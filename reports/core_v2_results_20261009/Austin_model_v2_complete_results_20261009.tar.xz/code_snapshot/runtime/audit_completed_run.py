#!/usr/bin/env python3
"""Read-only acceptance after an unbounded run; no solver is imported or started."""
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import argparse,csv,hashlib,json,math,os,tempfile,time,traceback

def read(p):return json.loads(Path(p).read_text())
def now():return datetime.now(ZoneInfo('America/Chicago')).isoformat(timespec='seconds')
def write(p,value):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
    fd,name=tempfile.mkstemp(dir=p.parent,prefix=p.name,suffix='.tmp')
    try:
        with os.fdopen(fd,'w') as f:json.dump(value,f,ensure_ascii=False,allow_nan=False,indent=2);f.write('\n')
        os.replace(name,p)
    finally:
        if os.path.exists(name):os.unlink(name)

def require(condition,message):
    if not condition:raise ValueError(message)

def close(x,y):return math.isclose(x,y,rel_tol=1e-9,abs_tol=1e-7)

def audit_trajectory(v,cfg):
    import numpy as np
    require(v['complete'] and v['stop_reason']=='completed' and not v['remaining'],'Unfinished repair trajectory')
    require(v.get('recovery_mode')=='until_complete' and v.get('observation_horizon_minutes') is None,'Observation horizon still active')
    events=v['events'];end=events[-1]['time'];initial=events[0]['remaining'];dispatch=v['dispatch']
    require(math.isfinite(end) and end>0 and events[0]['time']==0,'Invalid simulation times')
    require(len(dispatch)==len(initial) and {d['asset'] for d in dispatch}==set(initial),'Repairs are missing or duplicated')
    require(set(v['sequence'])==set(initial) and len(v['sequence'])==len(initial),'Invalid repair sequence')
    require(close(max(d['finish'] for d in dispatch),end),'Recovery ended before/after last completion')
    recovery=cfg['recovery'];counts={};allowed={}
    for kind in ('power','road'):
        count=recovery[kind+'_crews']
        if recovery.get('crew_model','fixed')=='per_damage':
            units=sum(a.startswith(kind+':') for a in initial)
            count=min(recovery['max_crews_per_trade'],math.ceil(units/recovery[kind+'_units_per_crew'])) if units else 0
        counts[kind]=count
        allowed.update({f'{kind}-{i}':kind for i in range(count)})
    require(v.get('crews',counts)==counts,'Crew counts differ from initial damage/configuration')
    available={crew:0. for crew in allowed}
    for d in dispatch:
        require(d['crew'] in allowed,'Unknown crew')
        kind=allowed[d['crew']]
        require(d['asset'].startswith(kind+':') and d['time']>=available[d['crew']]-1e-8,'Wrong crew or overlapping work')
        require(math.isfinite(d['travel_minutes']) and d['travel_minutes']>=0,'Invalid travel time')
        duration=recovery[kind+'_repair_minutes']
        if recovery.get('repair_time_model','fixed')=='severity':
            factor=initial[d['asset']];low,high=recovery[kind+'_repair_minutes_partial']
            duration=recovery[kind+'_repair_minutes_full'] if factor<=0 else low+(high-low)*min(1.,max(0.,1.-factor))
        require(close(d.get('repair_minutes',duration),duration),'Recorded repair duration differs from severity/configuration')
        require(close(d['finish'],d['time']+d['travel_minutes']+duration),'Invalid finish arithmetic')
        available[d['crew']]=d['finish']
    power=cfg['power'];traffic=cfg['traffic'];checks=0
    for e in events:
        require(math.isfinite(e['time']) and 0<=e['time']<=end,'Invalid event time')
        done={d['asset'] for d in dispatch if d['finish']<=e['time']+1e-8}
        require(set(e['remaining'])==set(initial)-done,'Event repair ledger mismatch')
        require(all(e['remaining'][a]==initial[a] for a in e['remaining']),'Damage changed without a completion event')
        q=e['traffic_quality']
        require(0<=q['relative_gap']<=traffic['relative_gap'] and q['max_node_imbalance']<=1e-4,'Traffic acceptance failed')
        require(len(e['power_operation'])==6,'Missing regional AC results')
        for r in e['power_operation']:
            require(r['feasible'] and r['converged'] and r['controls_settled'],'Infeasible/unconverged AC state')
            require(not r['unrated_energized_elements'] and r['max_thermal_loading_ratio']<=1+power['thermal_tolerance'],'Thermal acceptance failed')
            lo=r['min_loaded_voltage_pu'];hi=r['max_loaded_voltage_pu']
            lower=power['voltage_min_pu'];upper=power['voltage_max_pu']
            if power.get('operator','uniform_grid')=='local':
                # V2 accepts pre-existing base-case exceptions. Recheck saved
                # per-node violation counts and the overall reference envelope;
                # this is not a new AC solve or a legacy fixed-band assertion.
                require(power.get('limit_reference')=='healthy_base_case','Unknown local limit basis')
                require(r.get('voltage_violations')==0 and r.get('thermal_violations')==0,'Local operating-limit violations')
                reference=r.get('limit_reference')
                require(isinstance(reference,str) and len(reference)==64,'Missing healthy-reference digest')
                base=r.get('preexisting_base_case');require(isinstance(base,dict),'Missing base-case limit exceptions')
                if base.get('min_load_voltage_pu') is not None:lower=min(lower,base['min_load_voltage_pu'])
                if base.get('max_load_voltage_pu') is not None:upper=max(upper,base['max_load_voltage_pu'])
            require(lo is None or lo>=lower-power['voltage_tolerance'],'Low voltage')
            require(hi is None or hi<=upper+power['voltage_tolerance'],'High voltage')
            require(abs(r['active_balance_residual_kw'])<=max(.1,abs(r['source_kw'])*power['balance_relative_tolerance']),'AC balance failed')
            checks+=1
    require(close(events[-1]['power_func'],1) and close(events[-1]['road_func'],1),'Final functionality differs from healthy reference')
    times=np.asarray([e['time'] for e in events]);dt=np.diff(times)
    require(bool(np.all(dt>0)),'Event time failed to advance')
    eq=cfg['equity'];electric=np.asarray([e['electric'] for e in events]);access=np.asarray([e['access'] for e in events])
    cri=eq['electric_weight']*electric+eq['access_weight']*access;avg=(cri[:-1]*dt[:,None]).sum(axis=0)/end
    def first_hit(values,threshold):
        return [float(times[np.flatnonzero(values[:,i]>=threshold)[0]]) if np.any(values[:,i]>=threshold) else end for i in range(values.shape[1])]
    def gini(values):
        x=np.sort(values);n=len(x)
        return float(2*np.dot(np.arange(1,n+1),x)/(n*x.sum())-(n+1)/n) if x.sum()>0 else 0.
    restore=first_hit(cri,eq['cri_threshold']);ar=first_hit(access,eq['access_threshold'])
    pl=sum((1-e['power_func'])*d for e,d in zip(events,dt));rl=sum((1-e['road_func'])*d for e,d in zip(events,dt))
    expected=dict(power_loss=pl,road_loss=rl,triangle_area=pl+rl,
        weighted_triangle_area=sum((3-e['road_func']-e['weighted_power_func']-e['shelter_access'])*d for e,d in zip(events,dt)),
        gini_restore=gini(restore),var_restore=float(np.var(restore)),p90_restore=float(np.quantile(restore,.9)),p95_restore=float(np.quantile(restore,.95)),
        min_time_avg_cri=float(min(avg)),maximin_time_avg_cri_loss=float(1-min(avg)),mean_time_avg_cri=float(np.mean(avg)),
        p90_access_restore=float(np.quantile(ar,.9)),p95_access_restore=float(np.quantile(ar,.95)),gini_access_restore=gini(ar),
        gini_final_cri=gini(cri[-1]),mean_final_cri=float(np.mean(cri[-1])),min_final_cri=float(min(cri[-1])),
        shelter_access_initial=events[0]['shelter_access'],shelter_access_final=events[-1]['shelter_access'],completion_or_censor_time=end,
        censored_cri_zones=int(np.sum(~np.any(cri>=eq['cri_threshold'],axis=0))),
        censored_access_zones=int(np.sum(~np.any(access>=eq['access_threshold'],axis=0))))
    require(set(expected)==set(v['metrics']),'Unknown/missing metrics')
    for k,x in expected.items():require(close(x,v['metrics'][k]),'Metric differs from event recomputation: '+k)
    return dict(end_minutes=end,events=len(events),regional_physical_checks=checks,metrics_checked=len(expected),
                crews=counts,power_operator=power.get('operator','uniform_grid'),
                voltage_audit='saved per-node violation counts and healthy-reference envelope' if power.get('operator')=='local' else 'fixed voltage band')

def audit(output):
    output=Path(output);spec=read(output/'control/launch.json');cfg=spec['config'];state=read(output/'control/status.json')
    require(state['status']=='completed','Supervisor has not completed')
    require(not cfg['recovery'].get('stop_at_horizon',True),'This auditor expects until-complete mode')
    validation=read(output/'validation.json');require(validation['passed'] and validation['fingerprint']==spec['fingerprint'],'Physical gate missing')
    require(not list((output/'results').glob('*/*.error.json')),'Task errors remain')
    counts={};evaluations=[];permutations=0;iterations=0;original_hashes={}
    for stage,expected in spec['stage_job_counts'].items():
        if not expected:continue
        plan=read(output/'plans'/f'{stage}.json');require(plan['fingerprint']==spec['fingerprint'],'Plan fingerprint mismatch')
        files=sorted((output/'results'/stage).glob('*.json'));require(len(files)==expected,'Wrong result count for '+stage)
        seen=set()
        for p in files:
            d=read(p);require(d['fingerprint']==spec['fingerprint'],'Result fingerprint mismatch')
            seen.add(d['job']['id']);v=d['payload'];original_hashes[str(p.relative_to(output))]=hashlib.sha256(p.read_bytes()).hexdigest()
            if stage=='construct':
                require(v['permutations']==cfg['task_a']['shapley_permutations'],'Incomplete construction permutations')
                permutations+=v['permutations']
            else:
                check=audit_trajectory(v,cfg);iterations+=v.get('optimization',{}).get('iterations',0)
                evaluations.append(dict(stage=stage,strategy=d['job']['strategy'],scenario_id=v['scenario_id'],scenario_seed=v['scenario_seed'],**check))
        require(seen=={j['id'] for j in plan['jobs']},'Task IDs differ from plan')
        counts[stage]=len(files)
    require(read(output/'analysis/status.json')['complete'],'Analysis incomplete')
    answer=dict(passed=True,checked_at=now(),fingerprint=spec['fingerprint'],stage_counts=counts,total_tasks=sum(counts.values()),
        evaluation_trajectories=len(evaluations),incomplete_repairs=0,construction_permutations=permutations,sa_iterations=iterations,
        longest_recovery_minutes=max(r['end_minutes'] for r in evaluations),trajectories=evaluations,source_sha256=original_hashes,
        scope='Program/result acceptance under unchanged model assumptions; not proof of real-world disaster/traffic calibration',solvers_started=0)
    write(output/'control/completion_acceptance.json',answer);return answer

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('output',type=Path);p.add_argument('--watch',action='store_true');a=p.parse_args()
    control=a.output/'control';initial=read(control/'status.json');spec=read(control/'launch.json')
    write(control/'completion_auditor.json',dict(pid=os.getpid(),started_at=now(),mode='watch' if a.watch else 'once',fingerprint=spec['fingerprint']))
    try:
        if a.watch:
            while True:
                s=read(control/'status.json')
                require(s['fingerprint']==spec['fingerprint'] and s.get('started_or_resumed_at')==initial.get('started_or_resumed_at'),'Launch changed; auditor will not inspect a different run')
                if s['status']!='running':break
                require(Path(f"/proc/{s['supervisor_pid']}").exists(),'Supervisor disappeared')
                time.sleep(60)
        r=audit(a.output)
        print(json.dumps({k:v for k,v in r.items() if k not in ['trajectories','source_sha256']},ensure_ascii=False),flush=True)
    except Exception as exc:
        write(control/'completion_acceptance.json',dict(passed=False,checked_at=now(),error=f'{type(exc).__name__}: {exc}',traceback=traceback.format_exc(),solvers_started=0))
        raise

if __name__=='__main__':main()
