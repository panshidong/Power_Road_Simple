/* A feasible acyclic bush must remain acyclic after shortcut insertion.
 * Node IDs: 0 = origin, 1 = C, 2 = A, 3 = B.
 * Old bush: 0->C->A->B, plus 0->A and 0->B.
 * A->B ties the direct shortest route to B but has zero flow. Ignoring that
 * tied arc in the longest-path labels admits B->C and creates C->A->B->C.
 */
#include <assert.h>
#include <stdlib.h>
#include <string.h>
#include "parallel_bush.h"

int main(int argc, char **argv) {
    assert(argc == 3);
    int parallel = atoi(argv[1]);
    int boundary = atoi(argv[2]);
    verbosity = LOW_NOTIFICATIONS;
    debugFile = openFile("fixture.log", "w");
    network_type n = {0};
    n.numNodes = n.numZones = 4;
    n.numArcs = 6;
    n.batchSize = n.numOrigins = n.numClasses = n.numBatches = 1;
    n.firstThroughNode = 0;
    n.nodes = calloc(4, sizeof(node_type));
    n.arcs = calloc(6, sizeof(arc_type));
    double demand[4] = {0, 0, 1, 1};
    double *demands[1] = {demand};
    n.demand = demands;
    int tails[6] = {0, 0, 0, 1, 2, 3};
    int heads[6] = {1, 2, 3, 2, 3, 1};
    double costs[6] = {4, 1, 2, 2, 1, 1};
    for (int a = 0; a < 6; a++) {
        n.arcs[a].tail = tails[a];
        n.arcs[a].head = heads[a];
        n.arcs[a].cost = costs[a];
        insertArcList(&n.nodes[tails[a]].forwardStar, &n.arcs[a],
                      n.nodes[tails[a]].forwardStar.tail);
        insertArcList(&n.nodes[heads[a]].reverseStar, &n.arcs[a],
                      n.nodes[heads[a]].reverseStar.tail);
    }
    algorithmBParameters_type p = initializeAlgorithmBParameters();
    bushes_type *b = createBushes(&n);
    free(b->merges[0]);
    b->numMerges[0] = 2;
    b->merges[0] = calloc(2, sizeof(merge_type *));
    for (int m = 0; m < 2; m++) b->merges[0][m] = createMerge(2);
    merge_type *a = b->merges[0][0], *z = b->merges[0][1];
    a->approach[0] = 1; a->approach[1] = 3;
    a->approachFlow[0] = 0; a->approachFlow[1] = 1;
    z->approach[0] = 2; z->approach[1] = 4;
    z->approachFlow[0] = 1; z->approachFlow[1] = boundary ? p.minLinkFlow : 0;
    /* At exactly minLinkFlow, A->B is retained even if no longer shortest.
     * It must also participate in the labels used to admit shortcuts. */
    if (boundary) n.arcs[4].cost = 2;
    b->pred[0][0] = NO_PATH_EXISTS;
    b->pred[0][1] = 0;
    b->pred[0][2] = merge2pred(0);
    b->pred[0][3] = merge2pred(1);
    for (int i = 0; i < 4; i++) b->bushOrder[0][i] = i;
    b->lastMerge[0] = 3;
    if (parallel) updateBushB_par(0, &n, b, &p);
    else updateBushB(0, &n, b, &p);
    assert(isInBush(0, 5, &n, b) == FALSE);
    assert(isInBush(0, 4, &n, b) == TRUE);
    int position[4];
    for (int i = 0; i < 4; i++) position[b->bushOrder[0][i]] = i;
    for (int k = 0; k < 6; k++) {
        if (isInBush(0, k, &n, b))
            assert(position[n.arcs[k].tail] < position[n.arcs[k].head]);
    }
    deleteBushes(&n, b);
    for (int i = 0; i < 4; i++) {
        clearArcList(&n.nodes[i].forwardStar);
        clearArcList(&n.nodes[i].reverseStar);
    }
    free(n.nodes); free(n.arcs);
    fclose(debugFile);
    return 0;
}
