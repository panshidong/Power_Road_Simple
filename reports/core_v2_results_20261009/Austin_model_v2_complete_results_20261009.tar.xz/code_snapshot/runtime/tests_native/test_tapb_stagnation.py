"""Real assignments exposing starvation by the adaptive bush-skip threshold.

The 24-node fixture (seed 2) stalls at gap ~2481 for all 200 iterations before
the fix. Both fixtures use synthetic demand and retain directed arc identities.
"""
import heapq
import math
from pathlib import Path
import re
import shutil
import subprocess
import tempfile
import unittest


def audit_assignment(network, trips, flows, log, tolerance=1e-4):
    """Independently check arc order, BPR costs, conservation and full-network gap."""
    text = Path(network).read_text()
    zones = int(re.search(r"<NUMBER OF ZONES>\s+(\d+)", text)[1])
    first_thru = int(re.search(r"<FIRST THRU NODE>\s+(\d+)", text)[1])
    arcs = [line.split()[:10] for line in text.splitlines()
            if line.strip() and line.strip()[0].isdigit()]
    records = [tuple(map(float, match)) for match in re.findall(
        r"\((\d+),(\d+)\)\s+(\S+)\s+(\S+)", Path(flows).read_text())]
    if len(arcs) != len(records):
        raise AssertionError("Arc count changed")
    adjacency = {}; balance = {}; tstt = 0.0
    for arc, (u, v, flow, cost) in zip(arcs, records):
        if (int(arc[0]), int(arc[1])) != (int(u), int(v)):
            raise AssertionError("Arc identity/order changed")
        if not math.isfinite(flow + cost) or flow < -1e-6 or cost < 0:
            raise AssertionError("Invalid flow or cost")
        expected = float(arc[4]) * (1 + float(arc[5]) * (flow / float(arc[2])) ** float(arc[6]))
        if not math.isclose(cost, expected, rel_tol=1e-5, abs_tol=2e-5):
            raise AssertionError(f"BPR cost mismatch on {(u, v)}: {cost} vs {expected}")
        adjacency.setdefault(int(u), []).append((int(v), cost))
        balance[int(u)] = balance.get(int(u), 0.0) + flow
        balance[int(v)] = balance.get(int(v), 0.0) - flow
        tstt += flow * cost
    demands = {}; supply = {}; origin = None
    for line in Path(trips).read_text().splitlines():
        match = re.match(r"\s*Origin\s+(\d+)", line)
        if match:
            origin = int(match[1]); demands[origin] = []
        elif origin is not None:
            for dest, quantity in re.findall(r"(\d+)\s*:\s*([\d.eE+-]+)\s*;", line):
                dest, quantity = int(dest), float(quantity)
                demands[origin].append((dest, quantity))
                supply[origin] = supply.get(origin, 0.0) + quantity
                supply[dest] = supply.get(dest, 0.0) - quantity
    imbalance = max(abs(balance.get(i, 0.0) - supply.get(i, 0.0))
                    for i in set(balance) | set(supply))
    if imbalance > 1e-4:
        raise AssertionError(f"Flow conservation failed: {imbalance}")
    sptt = 0.0
    for origin, od in demands.items():
        distances = {origin: 0.0}; heap = [(0.0, origin)]
        while heap:
            distance, node = heapq.heappop(heap)
            if distance != distances[node]:
                continue
            if node < first_thru and node != origin:
                continue
            for dest, cost in adjacency.get(node, []):
                value = distance + cost
                if value < distances.get(dest, math.inf):
                    distances[dest] = value
                    heapq.heappush(heap, (value, dest))
        for dest, quantity in od:
            if quantity:
                sptt += quantity * distances.get(dest, math.inf)
    if not math.isfinite(sptt) or sptt <= 0:
        raise AssertionError("Positive demand is not routed on original arcs")
    gap = tstt / sptt - 1
    # flows.txt rounds flow/cost to six decimals; allow only that rounding noise.
    if not -1e-6 <= gap <= tolerance + 1e-6:
        raise AssertionError(f"Independent full-network gap failed: {gap}")
    logged_gap = float(re.findall(r"Iteration\s+\d+:\s+gap\s+([\d.eE+-]+)", log)[-1])
    if not 0 <= logged_gap <= tolerance or abs(logged_gap - gap) > 1e-6:
        raise AssertionError(f"Reported/independent gap disagree: {logged_gap}, {gap}")
    logged_tstt = float(re.findall(r"Aggregate TSTT:\s+([\d.eE+-]+)", log)[-1])
    if not math.isclose(tstt, logged_tstt, rel_tol=1e-6):
        raise AssertionError("Reported TSTT disagrees with arc flows")
    return dict(independent_gap=gap, logged_gap=logged_gap, tstt=tstt,
                max_node_imbalance=imbalance, arcs=len(arcs), zones=zones)


class BushSkipStagnation(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        if not shutil.which("gcc"):
            raise unittest.SkipTest("gcc is required")
        cls.temp = tempfile.TemporaryDirectory()
        cls.addClassCleanup(cls.temp.cleanup)
        cls.folder = Path(cls.temp.name)
        vendor = Path(__file__).resolve().parents[2] / "vendor/tap-b"
        cls.binary = cls.folder / "tap"
        result = subprocess.run([
            "gcc", "-O2", "-pthread", "-fcommon", "-DPARALLELISM=1",
            "-I", str(vendor / "include"),
            *map(str, sorted((vendor / "src").glob("*.c"))),
            "-lm", "-o", str(cls.binary),
        ], capture_output=True, text=True, timeout=60)
        if result.returncode:
            raise AssertionError(result.stdout + result.stderr)

    def check_fixture(self, name, recovery):
        fixtures = Path(__file__).with_name("fixtures")
        net = fixtures / f"tapb_{name}_network.tntp"
        trips = fixtures / f"tapb_{name}_trips.tntp"
        for threads in (1, 2):
            with self.subTest(threads=threads):
                work = self.folder / f"{name}-{threads}"
                work.mkdir()
                result = subprocess.run([
                    str(self.binary), "1e-4", "1", str(net), str(trips), str(threads),
                ], cwd=work, capture_output=True, text=True, timeout=15)
                self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
                self.assertEqual("TAP-B recovery:" in result.stdout, recovery)
                audit_assignment(net, trips, work / "flows.txt", result.stdout)

    def test_stalled_assignment_recovers_at_original_tolerance(self):
        self.check_fixture("stalled", True)

    def test_ordinary_assignment_keeps_fast_path(self):
        self.check_fixture("ordinary", False)


if __name__ == "__main__":
    unittest.main()
