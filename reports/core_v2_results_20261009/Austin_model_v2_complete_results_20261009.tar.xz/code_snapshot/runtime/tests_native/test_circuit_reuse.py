"""Small real AC regression: python -m unittest discover -s runtime/tests_native -v."""
import importlib.util
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from austin_runtime.common import RUNTIME, atomic_json, config, read_json, sha_file, write_rows
from austin_runtime.power import NativeACFailure, PowerEngine


MODEL='''Clear
New Circuit.fixture bus1=source basekv=12.47 pu=1 phases=3
New Transformer.ta phases=3 windings=2 buses=[source a] conns=[wye wye] kvs=[12.47 .48] kvas=[100 100] xhl=2
New Transformer.tb phases=3 windings=2 buses=[source b] conns=[wye wye] kvs=[12.47 .48] kvas=[100 100] xhl=2
New RegControl.ra transformer=ta winding=2 vreg=120 band=2 ptratio=2.3094
New Line.feeder phases=3 bus1=b bus2=c r1=.001 x1=.001 r0=.001 x0=.001 length=1 normamps=200
New Fuse.f monitoredobj=Line.feeder ratedcurrent=100
New Line.tie phases=3 bus1=b bus2=a switch=yes normamps=200
Open Line.tie term=1
Open Line.tie term=2
New Capacitor.ca phases=3 bus1=a kv=.48 kvar=5
New CapControl.cc element=Transformer.ta terminal=2 capacitor=ca type=voltage ptratio=2.3094 onsetting=115 offsetting=125
New Load.la phases=3 bus1=a kv=.48 kw=20 kvar=4
New Load.lb phases=3 bus1=c kv=.48 kw=15 kvar=3
Set voltagebases=[12.47 .48]
CalcVoltageBases
'''


class NativeCircuitReuse(unittest.TestCase):
    def test_isolated_states_match_direct_ac_and_cache_survives_child_exit(self):
        self.check_isolated_states({})

    def test_pinned_allocator_real_ac_matches_direct_and_survives_recovery(self):
        library=RUNTIME/"build/native/libjemalloc.so.2"
        if not library.exists():self.skipTest("Optional pinned allocator is not installed")
        self.check_isolated_states(dict(native_allocator_path=str(library),native_allocator_sha256=sha_file(library)))

    def check_isolated_states(self, native_settings):
        spec=importlib.util.spec_from_file_location("profile_power",Path(__file__).resolve().parents[1]/"profile_power.py")
        profile=importlib.util.module_from_spec(spec);spec.loader.exec_module(profile)
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);model=root/"models/R/Master_runtime.dss"
            model.parent.mkdir(parents=True);model.write_text(MODEL)
            cfg=config();cfg["runtime"].update(prepared=str(root),cache=str(root/"cache"))
            cfg["power"].update(isolate_states=True,state_timeout_seconds=10)
            cfg["power"].update(native_settings)
            catalog=dict(regions=["R"],signals=[],substation_region={},assets={
                "power:a":dict(region="R",isolation_transformers=["transformer.ta"])})
            atomic_json(root/"catalog.json",catalog)
            write_rows(root/"load_catalog.csv.gz",[
                dict(region="R",load_id="la",kw=20,kvar=4,zone="1",substation_id="a"),
                dict(region="R",load_id="lb",kw=15,kvar=3,zone="2",substation_id="b")])
            engine=PowerEngine(cfg,catalog,"fixture",root/"scratch")
            try:
                for damage in ({},{"power:a":0.},{"power:a":.2}):
                    direct=engine._operate("R",damage)
                    isolated=engine._regional_state("R",damage)
                    self.assertFalse(list(profile.differences(isolated,direct)))
                engine.memory.clear()
                with patch.object(engine,"_operate_isolated",side_effect=AssertionError("Existing cache re-solved")):
                    self.assertTrue(engine._regional_state("R",{})["feasible"])
                attempts=list((root/"scratch").glob("ac-*/result.json"))
                self.assertEqual(len(attempts),3)
                self.assertEqual(len({read_json(p)["pid"] for p in attempts}),3)
                for p in attempts:self.assertFalse(Path(f"/proc/{read_json(p)['pid']}").exists())
                # Controlled fault injection; both recovery/confirmation solves
                # below are real independent native processes, never mocks.
                direct=engine._operate("R",{"power:a":.3})
                native=engine._operate_isolated;calls=[]
                failure=root/"injected";failure.mkdir()
                def interrupt_once(*args):
                    calls.append(args)
                    if len(calls)==1:
                        raise NativeACFailure("injected signal failure",returncode=-8,directory=failure,retryable=True)
                    return native(*args)
                with patch.object(engine,"_operate_isolated",side_effect=interrupt_once):
                    recovered=engine._regional_state("R",{"power:a":.3})
                self.assertEqual(len(calls),3)
                self.assertFalse(list(profile.differences(recovered,direct)))
                audit=read_json(failure/"recovery.json")
                self.assertEqual(audit["status"],"recovered_and_confirmed")
                pids=[read_json(Path(audit[k])/"result.json")["pid"] for k in ("recovery_directory","confirmation_directory")]
                self.assertEqual(len(set(pids)),2)
            finally:engine.close()

    def test_cold_and_reused_circuits_agree_after_faults_ties_and_restoration(self):
        spec=importlib.util.spec_from_file_location("profile_power",Path(__file__).resolve().parents[1]/"profile_power.py")
        profile=importlib.util.module_from_spec(spec);spec.loader.exec_module(profile)
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);model=root/"models/R/Master_runtime.dss"
            model.parent.mkdir(parents=True);model.write_text(MODEL)
            cfg=config();cfg["runtime"]["prepared"]=str(root)
            catalog=dict(regions=["R"],signals=[],substation_region={},assets={
                "power:a":dict(region="R",isolation_transformers=["transformer.ta"])})
            write_rows(root/"load_catalog.csv.gz",[
                dict(region="R",load_id="la",kw=20,kvar=4,zone="1",substation_id="a"),
                dict(region="R",load_id="lb",kw=15,kvar=3,zone="2",substation_id="b")])
            cases=[({},1.,[]),({"power:a":0.},1.,[]),({"power:a":0.},1.,["Line.tie"]),
                   ({},.2,[]),({"power:a":.2},.4,[]),({},1.,[])]
            results={}
            for reuse in (False,True):
                cfg["power"]["reuse_circuit"]=reuse
                engine=PowerEngine(cfg,catalog,"fixture",root/str(reuse))
                results[reuse]=[]
                try:
                    for index,(damage,scale,ties) in enumerate(cases):
                        deratings,disabled=engine._compile("R",damage,scale,ties)
                        engine.dss.Solution.Solve()
                        self.assertTrue(engine.dss.Solution.Converged())
                        self.assertTrue(engine.dss.Solution.ControlActionsDone())
                        measured=engine._measure("R",scale,ties,deratings)
                        results[reuse].append(measured)
                        for name in disabled:
                            engine.dss.Circuit.SetActiveElement("Transformer."+name)
                            self.assertFalse(engine.dss.CktElement.Enabled())
                        if index==2:
                            # Actuators must be restored even after a protection
                            # action/capacitor operation in the preceding state.
                            engine.dss.Fuses.Name("f");engine.dss.Fuses.Open()
                            engine.dss.Capacitors.Name("ca");engine.dss.Capacitors.States([0])
                    # The normal tie search still restores the isolated feeder.
                    operated=engine._operate("R",{"power:a":0.})
                    self.assertTrue(operated["closed_switches"])
                    self.assertTrue(operated["feasible"])
                    results[reuse].append(operated)
                    if reuse:self.assertEqual(engine.stats["circuit_loads"],1)
                finally:engine.close()
            self.assertFalse(list(profile.differences(results[True],results[False])))
            self.assertLess(results[True][1]["served_kw"],results[True][2]["served_kw"])
            self.assertFalse(list(profile.differences(results[True][5],results[True][0])))


if __name__=="__main__":unittest.main()
