"""Compile the native graph-update regression; no Austin assignment is run."""
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest


class BushCycles(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        if not shutil.which("gcc"):
            raise unittest.SkipTest("gcc is required for the native TAP-B regression")
        cls.temp = tempfile.TemporaryDirectory()
        cls.addClassCleanup(cls.temp.cleanup)
        cls.folder = Path(cls.temp.name)
        project = Path(__file__).resolve().parents[2]
        vendor = project / "vendor/tap-b"
        cls.binary = cls.folder / "cycle-fixture"
        sources = sorted(p for p in (vendor / "src").glob("*.c") if p.name != "main.c")
        result = subprocess.run([
            "gcc", "-O2", "-pthread", "-fcommon", "-DPARALLELISM=1",
            "-I", str(vendor / "include"),
            str(Path(__file__).with_name("tapb_cycle_fixture.c")),
            *map(str, sources), "-lm", "-o", str(cls.binary),
        ], text=True, capture_output=True, timeout=60)
        if result.returncode:
            raise AssertionError(result.stdout + result.stderr)

    def test_tied_shortest_routes_remain_acyclic(self):
        self.check_case(boundary=0)

    def test_flow_exactly_at_cutoff_remains_acyclic(self):
        self.check_case(boundary=1)

    def check_case(self, boundary):
        for parallel in (0, 1):
            with self.subTest(parallel=parallel):
                result = subprocess.run(
                    [str(self.binary), str(parallel), str(boundary)],
                    cwd=self.folder, text=True, capture_output=True, timeout=10,
                )
                self.assertEqual(result.returncode, 0, result.stdout + result.stderr)


if __name__ == "__main__":
    unittest.main()
